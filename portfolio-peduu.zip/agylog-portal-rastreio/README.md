# Portal de Rastreio AgyLog

> Portal web seguro para rastreamento de remessas da AgyLog/CorelliLog, com autenticação robusta e CAPTCHA visual customizado.

🔒 **Acesso:** Sistema interno — produção restrita

<p>
  <img src="https://img.shields.io/badge/Python-3776AB?style=flat&logo=python&logoColor=white"/>
  <img src="https://img.shields.io/badge/Flask-000000?style=flat&logo=flask&logoColor=white"/>
  <img src="https://img.shields.io/badge/nginx-009639?style=flat&logo=nginx&logoColor=white"/>
  <img src="https://img.shields.io/badge/HTTPS-Let's Encrypt-003A70?style=flat"/>
</p>

---

## Problema

A empresa precisava de um ponto de acesso controlado para clientes e operadores consultarem o status de suas remessas, sem expor dados operacionais a acessos não autorizados. Não havia orçamento para soluções pagas.

## Solução

Portal de acesso seguro com autenticação em duas etapas (credenciais + CAPTCHA), hospedado em VPS com domínio próprio e HTTPS — custo adicional zero.

---

## Funcionalidades

- ✅ Login com e-mail corporativo + senha
- ✅ CAPTCHA visual gerado server-side (sem dependência de terceiros)
- ✅ Indicador de status do sistema em tempo real ("Sistema Online")
- ✅ Fluxo de cadastro de novos usuários
- ✅ HTTPS com domínio próprio (`agylog.com.br`)
- ✅ Interface dark theme responsiva
- ✅ Proteção com criptografia avançada

---

## Screenshots

![Portal de Login](screenshots/portal-login.jpg)

---

## Arquitetura

```
[Usuário] → [nginx (HTTPS)] → [Gunicorn / Flask] → [Banco de Dados]
                ↑
         Let's Encrypt SSL
         Domínio: agylog.com.br
```

## Stack

| Camada | Tecnologia |
|---|---|
| Frontend | HTML · CSS · JavaScript |
| Backend | Python · Flask · Gunicorn |
| Servidor web | nginx (reverse proxy) |
| SSL/HTTPS | Let's Encrypt |
| Hospedagem | VPS Linux |
| Custo total | **R$ 0,00** |

---

> Parte do ecossistema AgyLog — 5 sistemas em produção, infraestrutura 100% open-source.
